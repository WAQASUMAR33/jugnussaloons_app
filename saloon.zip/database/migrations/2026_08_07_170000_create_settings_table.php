<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('brand_logo')->nullable();
            $table->string('brand_name')->default('Jugnu Saloon');
            $table->string('brand_slogan')->nullable()->default('Executive Hair Styling & Grooming');
            $table->text('brand_address')->nullable();
            $table->string('brand_phone1')->nullable();
            $table->string('brand_phone2')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
